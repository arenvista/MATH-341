
> [!info]
> [[Main]]
> [[Main|$\alpha$]]
> [Main](Main.md)
> [$\beta$](Main.md)[[Main]]