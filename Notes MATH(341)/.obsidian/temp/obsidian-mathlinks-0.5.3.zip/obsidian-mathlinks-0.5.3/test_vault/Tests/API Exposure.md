$$\begin{equation}
    e^{\pi i}=-1
\end{equation}$$
^0588a9

[[#^0588a9]]