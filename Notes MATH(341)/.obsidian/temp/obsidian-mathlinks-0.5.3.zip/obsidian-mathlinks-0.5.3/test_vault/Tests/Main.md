---
mathLink: $\sigma$
tags:
  - tagTest
aliases:
  - $\Sigma$
---

This note contains a `mathLink`. ^0283fa

# Section