* [[Main]]
* [[Main|$\alpha$]]
* [Main](Main.md)
* [$\beta$](Main.md)

1. [[Main]]
2. [[Main|$\alpha$]]
3. [Main](Main.md)
4. [$\beta$](Main.md)

> [[Main]]
> [[Main|$\alpha$]]
> [Main](Main.md)
> [$\beta$](Main.md)