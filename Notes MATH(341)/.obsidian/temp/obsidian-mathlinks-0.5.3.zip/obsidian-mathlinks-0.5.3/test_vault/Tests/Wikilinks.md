`[[Main]]`: [[Main]]
`[[Main.md]]`: [[Main.md]]
`[[Main|$\alpha$ $\beta$ hi]]`: [[Main|$\alpha$ $\beta$ hi]]
`[[Main.md|$\alpha$ $\beta$ hi]]`: [[Main|$\alpha$ $\beta$ hi]]