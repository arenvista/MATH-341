(text::[[Main]])
(text::[[Main|$\alpha$]])
[text::[[Main]]]
[text::[[Main|$\alpha$]]]

* (text::[[Main]])
* (text::[[Main|$\alpha$]])
* [text::[[Main]]]
* [text::[[Main|$\alpha$]]]

1. (text::[[Main]])
2. (text::[[Main|$\alpha$]])
3. [text::[[Main]]]
4. [text::[[Main|$\alpha$]]]

> (text::[[Main]])
> (text::[[Main|$\alpha$]])
> [text::[[Main]]]
> [text::[[Main|$\alpha$]]]

> [!info]
> (text::[[Main]])
> (text::[[Main|$\alpha$]])
> [text::[[Main]]]
> [text::[[Main|$\alpha$]]]
> - (text::[[Main]])
> - (text::[[Main|$\alpha$]])
> - [text::[[Main]]]
> - [text::[[Main|$\alpha$]]]