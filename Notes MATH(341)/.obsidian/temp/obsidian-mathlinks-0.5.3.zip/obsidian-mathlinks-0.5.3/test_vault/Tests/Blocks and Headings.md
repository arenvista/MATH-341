---
mathLink: $\sigma$
mathLink-blocks:
    my-id: $\beta$
---

## Sec $\pi$

A block
^my-id

`[[Blocks and Headings]]`: [[Blocks and Headings]]
`[[Blocks and Headings.md]]`: [[Blocks and Headings.md]]

Headings:
- `[[Blocks and Headings#Sec $\pi$]]`: [[Blocks and Headings#Sec $\pi$]]
- `[[Blocks and Headings.md#Sec $\pi$]]`: [[Blocks and Headings.md#Sec $\pi$]]
- `[[#Sec $\pi$]]`: [[#Sec $\pi$]]

Blocks:
- `[[Blocks and Headings#^my-id]]`: [[Blocks and Headings#^my-id]]
- `[[Blocks and Headings.md#^my-id]]`: [[Blocks and Headings.md#^my-id]]
- `[[#^my-id]]`: [[#^my-id]]