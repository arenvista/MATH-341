`[Main](Main.md)`: [Main](Main.md)
`[Main](Main)`: [Main](Main)
`[$\alpha$ $\beta$ hi](Main.md)`: [$\alpha$ $\beta$ hi](Main.md)
`[$\alpha$ $\beta$ hi](Main)`: [$\alpha$ $\beta$ hi](Main)